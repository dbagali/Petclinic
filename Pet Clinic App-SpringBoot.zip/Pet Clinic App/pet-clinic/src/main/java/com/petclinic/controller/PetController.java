package com.petclinic.controller;

import com.petclinic.dto.Pet;
import com.petclinic.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class PetController {

    @Autowired
    PetService petService;

    @GetMapping("/pets")
    public List<Pet> getAllPets() {

        return petService.getAllPets();
    }

    @GetMapping("/pets/name/{petName}")
    public Pet getPetByName(@PathVariable("petName") String petName) {

        return petService.getPetByName(petName);
    }

    @PostMapping("/pets")
    public void createPetDetails(@RequestBody Pet pet) {
        System.out.println("Received data " + pet.toString());
    }


}
