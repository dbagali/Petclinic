package com.petclinic.service;

import com.petclinic.dto.Pet;
import com.petclinic.dto.Vaccination;
import com.petclinic.entity.PetEntity;
import com.petclinic.entity.PetOwnerEntity;
import com.petclinic.entity.VaccinationEntity;
import com.petclinic.repo.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class PetClinicUtilites {

    public Pet convertPetEntityToDto(PetEntity petEntity) {
        Pet pet = new Pet();
        pet.setPetId(petEntity.getPetId());
        pet.setPetName(petEntity.getPetName());
        pet.setPetAge(petEntity.getPetAge());
        pet.setVaccinations(convertVaccinationEntityToDto(petEntity));
        return pet;
    }

    public List<Vaccination> convertVaccinationEntityToDto(PetEntity petEntity) {
        List<Vaccination> vaccinations = new ArrayList<>();
        petEntity.getVaccinationEntities().stream().forEach(vaccs -> {
            Vaccination vaccination = new Vaccination();
            vaccination.setVaccinationId(vaccs.getVaccinationId());
            vaccination.setVaccinationName(vaccs.getVaccinationName());
            vaccination.setVaccinationDate(vaccs.getVaccinationDate());
            vaccinations.add(vaccination);
        });
        return vaccinations;
    }

    public void convertOwnerDtoToEntity(Pet pet, PetEntity petEntity) {
        PetOwnerEntity petOwner = new PetOwnerEntity();
        petOwner.setOwnerId(pet.getPetOwner().getOwnerId());
        petOwner.setOwnerName(pet.getPetOwner().getOwnerName());
        petOwner.setTelephoneNumber(pet.getPetOwner().getTelephoneNumber());
        petEntity.setPetOwnerEntity(petOwner);
    }

    public void converVaccinationtDtoToEntity(Pet pet, PetEntity petEntity) {
        if (pet.getVaccinations() != null) {
            Set<VaccinationEntity> vaccinationEntities = pet.getVaccinations()
                    .stream().map(vaccination -> {
                        VaccinationEntity vaccinationEntity = new VaccinationEntity();
                        vaccinationEntity.setVaccinationId(vaccination.getVaccinationId());
                        vaccinationEntity.setVaccinationName(vaccination.getVaccinationName());
                        vaccinationEntity.setVaccinationDate(vaccination.getVaccinationDate());
                        return vaccinationEntity;
                    }).collect(Collectors.toSet());
            petEntity.setVaccinationEntities(vaccinationEntities);
        }
    }

}
