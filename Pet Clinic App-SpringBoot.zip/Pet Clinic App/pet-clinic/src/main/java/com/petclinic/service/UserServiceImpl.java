package com.petclinic.service;

import com.petclinic.dto.User;
import com.petclinic.entity.UserEntity;
import com.petclinic.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
public class UserServiceImpl {

    @Autowired
    UserRepository userRepository;

    public void registerUser(User user) {
        UserEntity userEntity = new UserEntity();
        userEntity.setUserId(user.getUserId());
        userEntity.setUserId(user.getEmailId());
        userEntity.setUserId(Arrays.toString(user.getPassword()));
        UserEntity entity = userRepository.save(userEntity);
    }

    public boolean login(User user) {
        if (userRepository.findByUserIdAndPassword(user.getUserId(), Arrays.toString(user.getPassword())).isPresent()) {
            return true;
        } else {
            return false;
        }
    }
}
