package com.petclinic.controller;

import com.petclinic.dto.User;
import com.petclinic.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @Autowired
    UserServiceImpl userService;

    @PostMapping("user/register")
    public ResponseEntity<String> register(User user) {
        userService.registerUser(user);
        return new ResponseEntity<String>("Registered successfully", HttpStatus.OK);
    }

    @PostMapping("user/login")
    public ResponseEntity<String> login(User user) {
        if (userService.login(user)) {
            return new ResponseEntity<String>("Registered successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("Authentication failed! Please verify user name/ password"
                    , HttpStatus.UNAUTHORIZED);
        }

    }
}
