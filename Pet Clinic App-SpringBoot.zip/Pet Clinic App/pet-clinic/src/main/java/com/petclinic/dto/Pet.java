package com.petclinic.dto;

import java.util.List;

public class Pet {

    private int petId;
    private String petName;
    private Double petAge;
    List<Vaccination> vaccinations;

    private PetOwner petOwner;

    public int getPetId() {
        return petId;
    }

    public void setPetId(int petId) {
        this.petId = petId;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public Double getPetAge() {
        return petAge;
    }

    public void setPetAge(Double petAge) {
        this.petAge = petAge;
    }

    public List<Vaccination> getVaccinations() {
        return vaccinations;
    }

    public void setVaccinations(List<Vaccination> vaccinations) {
        this.vaccinations = vaccinations;
    }

    public PetOwner getPetOwner() {
        return petOwner;
    }

    public void setPetOwner(PetOwner petOwner) {
        this.petOwner = petOwner;
    }
}
