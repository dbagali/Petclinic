package com.petclinic.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="PET_OWNER")
public class PetOwnerEntity {

    @Id
    private Long ownerId;

    @Column(name = "OWNER_NAME")
    private String ownerName;

    @Column(name = "TEL_NUM")
    private String telephoneNumber;

    @OneToMany(mappedBy = "petOwnerEntity")
    private List<PetEntity> petEntityList;

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public List<PetEntity> getPetEntityList() {
        return petEntityList;
    }

    public void setPetEntityList(List<PetEntity> petEntityList) {
        this.petEntityList = petEntityList;
    }
}
