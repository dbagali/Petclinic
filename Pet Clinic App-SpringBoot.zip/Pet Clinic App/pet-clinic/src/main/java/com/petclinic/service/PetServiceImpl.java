package com.petclinic.service;

import com.petclinic.dto.Pet;
import com.petclinic.dto.PetOwner;
import com.petclinic.entity.PetEntity;
import com.petclinic.repo.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PetServiceImpl implements PetService {

    @Autowired
    PetRepository petRepository;

    @Autowired
    PetClinicUtilites utilites;

    @Override
    public List<Pet> getAllPets() {
        List<PetEntity> petEntities = petRepository.findAll();
        return petEntities.stream().map(
                petEntity -> utilites.convertPetEntityToDto(petEntity))
                .collect(Collectors.toList());
    }

    @Override
    public void updatePetInfo(Pet pet) {
        Optional<PetEntity> petToBeUpdated = petRepository.findById(
                Integer.toUnsignedLong(pet.getPetId()));
        if (petToBeUpdated.isPresent()) {
            PetEntity petEntity = petToBeUpdated.get();
            petEntity.setPetAge(pet.getPetAge());
            petEntity.setPetName(pet.getPetName());
            utilites.convertOwnerDtoToEntity(pet, petEntity);
            utilites.converVaccinationtDtoToEntity(pet, petEntity);
            petRepository.save(petEntity);
        }
    }

    @Override
    public Pet getPetByName(String petName) {
        if (petRepository.findByPetName(petName).isPresent()) {
            PetEntity petEntity = petRepository.findByPetName(petName).get();
            Pet pet = new Pet();
            pet.setPetId(petEntity.getPetId());
            pet.setPetName(petEntity.getPetName());
            pet.setVaccinations(utilites.convertVaccinationEntityToDto(petEntity));
            pet.setPetAge(petEntity.getPetAge());
            PetOwner petOwner = new PetOwner();
            petOwner.setOwnerId(petEntity.getPetOwnerEntity().getOwnerId());
            petOwner.setOwnerName(petEntity.getPetOwnerEntity().getOwnerName());
            petOwner.setTelephoneNumber(petEntity.getPetOwnerEntity().getTelephoneNumber());
            pet.setPetOwner(petOwner);
            return pet;
        }
        return null;
    }
}
