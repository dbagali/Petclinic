package com.petclinic.service;

import com.petclinic.dto.Pet;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface PetService {
    List<Pet> getAllPets();

    void updatePetInfo(Pet pet);

    Pet getPetByName(String petName);
}
