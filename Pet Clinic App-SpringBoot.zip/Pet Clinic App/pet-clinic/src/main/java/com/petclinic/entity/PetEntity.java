package com.petclinic.entity;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="PET")
public class PetEntity {

    @Id
    @Column(name="PET_ID")
    private int petId;

    @Column(name="PET_NAME")
    private String petName;
    @Column(name="PET_AGE")
    private double petAge;
    @OneToMany(mappedBy = "pet")
    private Set<VaccinationEntity> vaccinationEntities;

    @ManyToOne
    @JoinColumn(name = "OWNER_ID", nullable = false)
    private PetOwnerEntity petOwnerEntity;
    public int getPetId() {
        return petId;
    }

    public void setPetId(int petId) {
        this.petId = petId;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public double getPetAge() {
        return petAge;
    }

    public void setPetAge(double petAge) {
        this.petAge = petAge;
    }

    public Set<VaccinationEntity> getVaccinationEntities() {
        return vaccinationEntities;
    }

    public void setVaccinationEntities(Set<VaccinationEntity> vaccinationEntities) {
        this.vaccinationEntities = vaccinationEntities;
    }

    public PetOwnerEntity getPetOwnerEntity() {
        return petOwnerEntity;
    }

    public void setPetOwnerEntity(PetOwnerEntity petOwnerEntity) {
        this.petOwnerEntity = petOwnerEntity;
    }
}
