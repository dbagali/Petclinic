package com.petclinic.ui.listeners;

import com.petclinic.ui.screens.EditDetailsPage;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;

public class PetTableSelectionListener implements ListSelectionListener {

    JTable table;
    private JTextField petNameEditTF;
    private JTextField petAgeEditTF;
    private JTextField petOwnerNameTF;
    private JTextField contactNoEditTF1;
    private JTextField vaccinationDateTF;

    private JTextField petIdTF;

    public PetTableSelectionListener(JTable resultTable, JTextField petNameEditTF, JTextField petAgeEditTF, JTextField petOwnerNameTF, JTextField contactNoEditTF1, JTextField vaccinationDateTF, JTextField petIdTF) {
        this.table = resultTable;
        this.petNameEditTF = petNameEditTF;
        this.petAgeEditTF = petAgeEditTF;
        this.petOwnerNameTF = petOwnerNameTF;
        this.contactNoEditTF1 = contactNoEditTF1;
        this.vaccinationDateTF = vaccinationDateTF;
        this.petIdTF = petIdTF;
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        int selectedRow = this.table.getSelectedRow();
        this.petNameEditTF.setText(getColumnValue(selectedRow, 1));
        this.petAgeEditTF.setText(getColumnValue(selectedRow, 2));
        this.petOwnerNameTF.setText(getColumnValue(selectedRow, 4));
        this.contactNoEditTF1.setText(getColumnValue(selectedRow, 5));
        this.vaccinationDateTF.setText(getColumnValue(selectedRow, 3));
        this.petIdTF.setText(getColumnValue(selectedRow, 0));
    }

    public String getColumnValue(int row, int column) {
        return this.table.getValueAt(row, column)!=null?this.table.getValueAt(row, column).toString():"";
    }
}
