package com.petclinic.ui.service;

import com.petclinic.ui.dto.User;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Hashtable;

public class UserService {

    public boolean login(User user) {
        try {
        final Hashtable jndiProperties = new Hashtable();
        jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY,  "org.wildfly.naming.client.WildFlyInitialContextFactory");
        jndiProperties.put(Context.PROVIDER_URL,"http-remoting://localhost:8080");
        final Context context;

            context = new InitialContext(jndiProperties);
             context.lookup("ejb:/ejb-server-basic/CalculatorEJB!com.itbuzzpress.chapter4.ejb.Calculator");
        } catch (NamingException e) {
            throw new RuntimeException(e);
        }


        return true;
    }



}
