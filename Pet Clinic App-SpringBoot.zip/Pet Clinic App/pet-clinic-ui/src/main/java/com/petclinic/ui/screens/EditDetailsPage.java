package com.petclinic.ui.screens;

import com.petclinic.ui.dto.Pet;
import com.petclinic.ui.dto.PetOwner;
import com.petclinic.ui.listeners.CancelActionListener;
import com.petclinic.ui.listeners.SubmitPetDetailsActionListener;

import javax.swing.*;
import java.awt.*;

public class EditDetailsPage {


    public JCollapsiblePanel preparePetEditPanel(JTable table) {
        JCollapsiblePanel collapsiblePanel = new JCollapsiblePanel("Edit Pet Information", Color.BLACK);
        collapsiblePanel.setLayout(new GridLayout(2, 1));
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new GridLayout(5, 2));

        JTextField petNameJTF = new JTextField(getColumnValue(table, 0));
        JTextField petAgeJTF = new JTextField(getColumnValue(table, 1));
        JTextField petVaccinationDateJTF = new JTextField(getColumnValue(table, 2));
        JTextField petOwnerJTF = new JTextField(getColumnValue(table, 3));
        JTextField petOwnerPhoneJTF = new JTextField(getColumnValue(table, 4));

        searchPanel.add(petNameJTF, 1, 0);
        searchPanel.add(petAgeJTF, 1, 1);
        searchPanel.add(petVaccinationDateJTF, 1, 2);
        searchPanel.add(petOwnerJTF, 1, 3);
        searchPanel.add(petOwnerPhoneJTF, 1, 4);

        JPanel submitPanel = new JPanel();
        submitPanel.setLayout(new GridLayout(1, 4));
        JButton submit = new JButton("Submit");
        Pet pet = new Pet();
        pet.setPetId(1);
        pet.setPetName(petNameJTF.getText());
        pet.setPetAge(Double.parseDouble(petAgeJTF.getText()));
        PetOwner petOwner = new PetOwner();
        petOwner.setOwnerName(petOwnerJTF.getText());
        petOwner.setTelephoneNumber(petOwnerPhoneJTF.getText());
        pet.setPetOwner(petOwner);
        submit.addActionListener(new SubmitPetDetailsActionListener(pet));
        submit.setBounds(0, 0, 80, 20);
        JButton cancel = new JButton("Cancel");
        submit.addActionListener(new CancelActionListener());
        cancel.setBounds(0, 0, 50, 20);
        submitPanel.add(submit);
        submitPanel.add(cancel);
        collapsiblePanel.add(searchPanel);
        collapsiblePanel.add(submitPanel);
        return collapsiblePanel;
    }

    private String getColumnValue(JTable table, int index) {
        return table.getValueAt(table.getSelectedRow(), index) != null ? table.getValueAt(table.getSelectedRow(), index).toString() : "";
    }

}
