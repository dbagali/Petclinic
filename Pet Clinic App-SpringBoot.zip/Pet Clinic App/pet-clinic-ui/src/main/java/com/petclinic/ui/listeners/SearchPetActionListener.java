package com.petclinic.ui.listeners;

import com.petclinic.ui.dto.Pet;
import com.petclinic.ui.dto.PetOwner;
import com.petclinic.ui.service.PetServiceImpl;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

public class SearchPetActionListener implements ActionListener {

    JTable table;

    JTextField searchPet;

    public SearchPetActionListener(JTable table, JTextField searchPet) {
        this.table = table;
        this.searchPet = searchPet;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        table.setSelectionMode(0);
        String[] columnNames = {"Pet ID","Pet Name", "Age", "Last Vaccination Time", "Owner Name", "Tel No."};
        PetServiceImpl petService = new PetServiceImpl();
        if (!searchPet.getText().isEmpty()) {
            String petName = searchPet.getText();
            Pet pet = petService.getPet(petName);
            System.out.println(pet.getVaccinations().get(0).getVaccinationDate().toString());
            PetTableModel petTableModel = new PetTableModel(null, columnNames);
            LocalDateTime vaccinationDate = pet.getVaccinations().stream().findFirst().get().getVaccinationDate();
            PetOwner petOwner = pet.getPetOwner()!=null?pet.getPetOwner():new PetOwner();
            Object[] value = {pet.getPetId(), pet.getPetName(), pet.getPetAge(), vaccinationDate!= null? vaccinationDate.toString(): "",
                    petOwner.getOwnerName(), petOwner.getTelephoneNumber()};
            petTableModel.addRow(value);
            table.setModel(petTableModel);
        } else {
            List<Pet> allPets = petService.getAllPets();
            PetTableModel petTableModel = new PetTableModel(null, columnNames);
            allPets.stream().forEach(pet -> {
                LocalDateTime vaccinationDate = pet.getVaccinations().stream().findFirst().get().getVaccinationDate();
                PetOwner petOwner = pet.getPetOwner()!=null?pet.getPetOwner():new PetOwner();
                Object[] value = {pet.getPetId(), pet.getPetName(), pet.getPetAge(), vaccinationDate!= null? vaccinationDate.toString(): "",
                        petOwner.getOwnerName(), petOwner.getTelephoneNumber()};
                petTableModel.addRow(value);
            });
            table.setModel(petTableModel);
        }
        table.revalidate();
        table.repaint();
        table.setVisible(true);
        table.getColumnModel().getColumn(0).setPreferredWidth(20);
    }
}
