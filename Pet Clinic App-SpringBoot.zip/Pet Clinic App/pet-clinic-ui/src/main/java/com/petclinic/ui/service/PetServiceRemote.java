package com.petclinic.ui.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.petclinic.ui.dto.Pet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class PetServiceRemote {

    public String getService(String URL) throws IOException {
        StringBuilder data = new StringBuilder();
        try {
            HttpURLConnection con = (HttpURLConnection) ((new URL(URL).openConnection()));
            con.setRequestMethod("GET");

            con.setDoInput(true);
            String s;
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                while ((s = in.readLine()) != null) {
                    data.append(s);
                }
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
            throw new MalformedURLException("URL is not valid");
        } catch (ProtocolException e) {
            e.printStackTrace();
            throw new ProtocolException("No such protocol, it must be POST,GET,PATCH,DELETE etc.");
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("Cannot read from server");
        }
        return data.toString();
    }

    public static void postService(Pet pet, String URL) throws IOException {

        try {
            HttpURLConnection con = (HttpURLConnection) ((new URL(URL).openConnection()));
            con.setDoOutput(true);
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");

            try (OutputStream out = con.getOutputStream()) {
                ObjectMapper objectMapper = new ObjectMapper();
                objectMapper.registerModule(new JavaTimeModule());
                out.write(objectMapper.writeValueAsString(pet).getBytes());
                System.out.println("Success");
            }

            int resp = con.getResponseCode();

            System.out.println("Response cocde: " + resp);

        } catch (ProtocolException e) {
            e.printStackTrace();
            throw new ProtocolException("No such protocol, protocol must be POST,DELETE,PATCH,GET etc.");
        } catch (MalformedURLException e) {
            e.printStackTrace();
            throw new MalformedURLException("URL is not valid");
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("Cannot write information to server");
        }

    }
}
