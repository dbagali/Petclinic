package com.petclinic.ui.listeners;

import com.petclinic.ui.dto.Pet;
import com.petclinic.ui.service.PetServiceRemote;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Arrays;

public class SubmitPetDetailsActionListener implements ActionListener {

    Pet pet;

    public SubmitPetDetailsActionListener(Pet pet) {
        this.pet = pet;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        PetServiceRemote petServiceRemote = new PetServiceRemote();
        String PET_SERVICE_URL = "http://localhost:9001/pets";
        try {
            petServiceRemote.postService(pet, PET_SERVICE_URL);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    private String getColumnValue(JTable table, int index) {
        return table.getValueAt(table.getSelectedRow(), index) != null ? table.getValueAt(table.getSelectedRow(), index).toString() : "";
    }
}
