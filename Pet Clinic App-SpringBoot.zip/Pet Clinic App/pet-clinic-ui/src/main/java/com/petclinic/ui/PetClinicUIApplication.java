package com.petclinic.ui;

import com.petclinic.ui.screens.LandingPage;
import com.petclinic.ui.screens.Login;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PetClinicUIApplication {

    public static void main(String[] args) throws Exception {
        loadPage();
    }
    public static void loadPage() throws Exception {
        Login dialog = new Login();
        dialog.getButtonOK().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("The Pet clinic");
                LandingPage landingPage = new LandingPage(frame);
                if (dialog.onOK()) {
                    dialog.dispose();
                    frame.setVisible(true);
                } else {
                    dialog.setVisible(true);
                    frame.setVisible(false);
                }

            }
        });

        dialog.getButtonCancel().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.onCancel();
            }
        });
        dialog.setSize(400, 230);
        final Toolkit toolkit = Toolkit.getDefaultToolkit();
        final Dimension screenSize = toolkit.getScreenSize();
        final int x = (screenSize.width - dialog.getWidth()) / 2;
        final int y = (screenSize.height - dialog.getHeight()) / 2;
        dialog.setLocation(x, y);
        dialog.setVisible(true);
    }


}
