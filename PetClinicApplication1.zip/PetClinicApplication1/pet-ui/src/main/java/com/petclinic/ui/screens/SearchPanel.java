package com.petclinic.ui.screens;

import com.petclinic.ui.dto.Pet;
import com.petclinic.ui.dto.PetOwner;
import com.petclinic.ui.dto.Vaccination;
import com.petclinic.ui.listeners.PetTableSelectionListener;
import com.petclinic.ui.listeners.SearchPetActionListener;
import com.petclinic.ui.service.PetServiceRemote;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class SearchPanel extends Frame {
    private JPanel searchPanel;
    private JPanel displayPanel;
    private JPanel editPanel;
    private JTable resultTable;
    private JLabel searchPetLabel;
    private JTextField searchPet;
    private JButton searchButton;
    private JPanel mainPanel;
    private JButton sumitButton;
    private JTextField petNameEditTF;
    private JTextField petAgeEditTF;
    private JTextField petOwnerNameTF;
    private JPanel editPanel12;
    private JLabel contactNoLabel;
    private JTextField contactNoEditTF1;
    private JTextField vaccinationDateTF;
    private JPanel editPanelInfo;
    private JLabel validationMessage;
    private JTextField petIdTF;
    private JLabel petIdLabel;

    public SearchPanel() throws HeadlessException {
        super();
        resultTable.getSelectionModel().addListSelectionListener(new PetTableSelectionListener(
                resultTable, petNameEditTF, petAgeEditTF,petOwnerNameTF,
                contactNoEditTF1, vaccinationDateTF, petIdTF));
        searchButton.addActionListener(new SearchPetActionListener(resultTable, searchPet));
        sumitButton.addActionListener((ActionEvent e)-> {
            validationMessage.setForeground(Color.RED);
            LocalDateTime localDateTime = LocalDateTime.parse(vaccinationDateTF.getText());
            if (petNameEditTF.getText().isEmpty() || petNameEditTF.getText().length()<=2) {
                validationMessage.setText("Pet name is empty or less than 2 character");
            } else if (localDateTime.isAfter(LocalDateTime.now())) {
                validationMessage.setText("Vaccination date cannot be in future");
            } else if (contactNoEditTF1.getText().isEmpty() || contactNoEditTF1.getText().length() < 10) {
                String regex = "[0-9]+";
                Pattern p = Pattern.compile(regex);
                if (!p.matcher(contactNoEditTF1.getText()).matches()) {
                    validationMessage.setText("Invalid contact number");
                }
            }
            Pet pet = new Pet();
            pet.setPetId(1);
            pet.setPetName(petNameEditTF.getText());
            pet.setPetAge(Double.parseDouble(petAgeEditTF.getText()));
            PetOwner petOwner = new PetOwner();
            petOwner.setOwnerName(petOwnerNameTF.getText());
            petOwner.setTelephoneNumber(contactNoEditTF1.getText());
            List<Vaccination> vaccinations = new ArrayList<>();
            Vaccination vaccination = new Vaccination();
            vaccination.setVaccinationDate(localDateTime);
            vaccinations.add(vaccination);
            pet.setVaccinations(vaccinations);
            pet.setPetOwner(petOwner);

            PetServiceRemote petServiceRemote = new PetServiceRemote();
            String PET_SERVICE_URL = "http://localhost:9001/pets";
            try {
                petServiceRemote.postService(pet, PET_SERVICE_URL);
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
    }
    public JPanel getMainPanel() {
        return mainPanel;
    }
}
