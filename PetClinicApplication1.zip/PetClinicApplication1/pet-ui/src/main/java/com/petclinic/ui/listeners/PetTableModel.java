package com.petclinic.ui.listeners;

import javax.swing.table.DefaultTableModel;

public class PetTableModel extends DefaultTableModel {
    String[] columnNames;
    String[][] data;

    public PetTableModel(String[][] data, String[] columnNames) {
        super(data, columnNames);
    }
}
