package com.petclinic.ui.service;

import com.petclinic.ejb.PetRemote;
import com.petclinic.ejb.PetRemoteImpl;
import com.petclinic.ejb.UserRemote;
import com.petclinic.ejb.UserRemoteImpl;
/*import org.wildfly.naming.client.WildFlyInitialContextFactory;
import org.wildfly.naming.client.WildFlyInitialContextFactoryBuilder;*/

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Hashtable;
import java.util.Properties;

public class EJBFactory {

        public static PetRemote lookupPetRemoteBean
          (String namespace) throws NamingException {
            Context ctx = createInitialContext();
            String appName = "";
            String moduleName = "pet-service";
            String distinctName = "";
            String beanName = PetRemoteImpl.class.getSimpleName();
            String viewClassName = PetRemote.class.getName();
            return (PetRemote) ctx.lookup(namespace
              + appName + "/" + moduleName 
              + "/" + distinctName + "/" + beanName + "!" + viewClassName);
        }

    public static UserRemote lookupUserRemoteBean
            (String namespace) throws NamingException {
        Context ctx = createInitialContext();
        String appName = "";
        String moduleName = "pet-service";
        String distinctName = "";
        String beanName = UserRemoteImpl.class.getSimpleName();
        String viewClassName = UserRemote.class.getName();
        return (UserRemote) ctx.lookup(namespace
                + appName + "/" + moduleName
                + "/" + distinctName + "/" + beanName + "!" + viewClassName);
    }

        private static Context createInitialContext() throws NamingException {
            Hashtable<String, String> jndiProperties = new Hashtable<>();
            jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY, 
              "org.wildfly.naming.client.WildFlyInitialContextFactory");
            jndiProperties.put(Context.URL_PKG_PREFIXES, 
              "org.jboss.ejb.client.naming");
            jndiProperties.put(Context.PROVIDER_URL, 
               "http-remoting://127.0.0.1:8080");
           // jndiProperties.put("jboss.naming.client.ejb.context", true);
            return new InitialContext(jndiProperties);
        }




/*    private static WildFlyInitialContextFactory wildFlyInitialContextFactory() throws NamingException {
        Hashtable<String, String> jndiProperties = new Hashtable<>();
     *//*   jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY,
                "org.jboss.naming.remote.client.InitialContextFactory");*//*
        jndiProperties.put(Context.URL_PKG_PREFIXES,
                "org.jboss.ejb.client.naming");
    *//*    jndiProperties.put(Context.PROVIDER_URL,
                "http-remoting://localhost:8080");*//*
        return new WildFlyInitialContextFactoryBuilder().createInitialContextFactory(jndiProperties);
    }*/
    }