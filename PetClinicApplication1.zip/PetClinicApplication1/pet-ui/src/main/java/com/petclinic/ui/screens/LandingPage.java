package com.petclinic.ui.screens;
import javax.swing.*;
public class LandingPage {
    public LandingPage(JFrame frame) {
        SearchPanel searchPanel = new SearchPanel();
        frame.setContentPane(searchPanel.getMainPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setBounds(600, 200, 800, 500);
    }


}
