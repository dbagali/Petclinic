package com.petclinic.ui.service;

import com.petclinic.dto.User;
import com.petclinic.ejb.UserRemote;
import javax.naming.NamingException;

public class UserService {

    public boolean login(User user) {
        try {
            UserRemote userRemote = EJBFactory.lookupUserRemoteBean("ejb:");
            userRemote.login(user);
        } catch (NamingException e) {
            throw new RuntimeException(e);
        }


        return true;
    }



}
