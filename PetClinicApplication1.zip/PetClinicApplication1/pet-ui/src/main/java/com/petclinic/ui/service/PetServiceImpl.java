package com.petclinic.ui.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import com.petclinic.ui.dto.Pet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.List;

public class PetServiceImpl {

    private static final String PET_SERVICE_URL = "http://localhost:9001/pets";


    public Pet getPet(String name) {
        PetServiceRemote remote = new PetServiceRemote();
        try {
            String data = remote.getService(PET_SERVICE_URL+"/name/"+ name);
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            Pet pet = objectMapper.readValue(data, Pet.class);
            return pet;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Pet> getAllPets() {
        PetServiceRemote remote = new PetServiceRemote();
        try {
            String data = remote.getService(PET_SERVICE_URL);
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            List<Pet> pets = objectMapper.readValue(data, new TypeReference<List<Pet>>() {});
            return pets;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
