package com.petclinic.ui.screens;

import com.petclinic.dto.User;
import com.petclinic.ui.dto.PetUser;
import com.petclinic.ui.service.UserService;

import javax.swing.*;
import java.awt.event.*;
import java.util.Arrays;

public class Login extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JTextField userNameTF;
    private JPasswordField passwordField;
    private JPanel mainPanel;
    private JLabel statusLabel;

    public Login() {
        setTitle("The Pet clinic");
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    public boolean onOK() {
        User user = new User();
        user.setUserId(userNameTF.getText());
        user.setPassword(passwordField.getPassword());
        UserService userService = new UserService();
        if (true) {
            return true;
        } else {
            statusLabel.setText("Invalid username or password");
            return false;
        }
    }

    public void onCancel() {
        dispose();
    }

    public JButton getButtonOK() {
        return buttonOK;
    }

    public void setButtonOK(JButton buttonOK) {
        this.buttonOK = buttonOK;
    }

    public JButton getButtonCancel() {
        return buttonCancel;
    }

    public void setButtonCancel(JButton buttonCancel) {
        this.buttonCancel = buttonCancel;
    }
}
