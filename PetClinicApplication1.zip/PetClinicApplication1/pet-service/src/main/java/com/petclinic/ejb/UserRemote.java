package com.petclinic.ejb;

import com.petclinic.dto.User;

import javax.ejb.Remote;

@Remote
public interface UserRemote {

    public boolean login(User user);
}
