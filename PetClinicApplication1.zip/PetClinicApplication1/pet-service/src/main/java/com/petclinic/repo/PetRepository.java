package com.petclinic.repo;
import com.petclinic.entity.PetEntity;

import javax.enterprise.inject.Default;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.List;
import java.util.Optional;

@Named
@Default
public class PetRepository {

    public List<PetEntity> findAll(){
        EntityManager entityManager = PersistenceUtils.getEntityManager();
        return entityManager.createQuery("SELECT p FROM PET p").getResultList();
    }

    public Optional<PetEntity> findById(long id) {
        EntityManager entityManager = PersistenceUtils.getEntityManager();
        TypedQuery<PetEntity> query = entityManager.createQuery("SELECT p FROM PET p WHERE p.PET_ID=?1", PetEntity.class);
        PetEntity singleResult = query.setParameter(1, id).getSingleResult();
        return Optional.of(singleResult);
    }

    public void save(PetEntity petEntity) {
        EntityManager entityManager = PersistenceUtils.getEntityManager();
        entityManager.persist(petEntity);
    }

    public Optional<PetEntity> findByPetName(String petName) {
        EntityManager entityManager = PersistenceUtils.getEntityManager();
        TypedQuery<PetEntity> query = entityManager.createQuery("SELECT p FROM PET p WHERE p.PET_NAME=?1", PetEntity.class);
        PetEntity singleResult = query.setParameter(1, petName).getSingleResult();
        return Optional.of(singleResult);
    }
}
