package com.petclinic.ejb;

import com.petclinic.dto.Pet;
import com.petclinic.dto.PetOwner;
import com.petclinic.entity.PetEntity;
import com.petclinic.repo.PetRepository;
import com.petclinic.service.PetClinicUtilites;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Stateless(name = "pet")
public class PetRemoteImpl implements PetRemote {
    PetRepository petRepository;

    private PetClinicUtilites utilites;

    @PostConstruct
    public void init() {
        utilites = new PetClinicUtilites();
        petRepository = new PetRepository();
    }

    public List<Pet> getAllPets() {
        List<PetEntity> petEntities = petRepository.findAll();
        return petEntities.stream().map(
                        petEntity -> utilites.convertPetEntityToDto(petEntity))
                .collect(Collectors.toList());
    }


    public void updatePetInfo(Pet pet) {
        Optional<PetEntity> petToBeUpdated = petRepository.findById(
                Integer.toUnsignedLong(pet.getPetId()));
        if (petToBeUpdated.isPresent()) {
            PetEntity petEntity = petToBeUpdated.get();
            petEntity.setPetAge(pet.getPetAge());
            petEntity.setPetName(pet.getPetName());
            utilites.convertOwnerDtoToEntity(pet, petEntity);
            utilites.converVaccinationtDtoToEntity(pet, petEntity);
            petRepository.save(petEntity);
        }
    }


    public Pet getPetByName(String petName) {
        if (petRepository.findByPetName(petName).isPresent()) {
            PetEntity petEntity = petRepository.findByPetName(petName).get();
            Pet pet = new Pet();
            pet.setPetId(petEntity.getPetId());
            pet.setPetName(petEntity.getPetName());
            pet.setVaccinations(utilites.convertVaccinationEntityToDto(petEntity));
            pet.setPetAge(petEntity.getPetAge());
            PetOwner petOwner = new PetOwner();
            petOwner.setOwnerId(petEntity.getPetOwnerEntity().getOwnerId());
            petOwner.setOwnerName(petEntity.getPetOwnerEntity().getOwnerName());
            petOwner.setTelephoneNumber(petEntity.getPetOwnerEntity().getTelephoneNumber());
            pet.setPetOwner(petOwner);
            return pet;
        }
        return null;
    }
}
