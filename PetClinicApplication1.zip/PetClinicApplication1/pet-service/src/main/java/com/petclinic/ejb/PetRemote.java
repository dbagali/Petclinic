package com.petclinic.ejb;

import com.petclinic.dto.Pet;

import javax.ejb.Remote;
import java.util.List;

@Remote
public interface PetRemote {

    List<Pet> getAllPets();

    void updatePetInfo(Pet pet);

    Pet getPetByName(String petName);

}
