package com.petclinic.repo;
import com.petclinic.entity.PetEntity;
import com.petclinic.entity.UserEntity;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.Optional;


public class UserRepository {
    public Optional<UserEntity> findByUserIdAndPassword(String userId, String toString) {
           EntityManager entityManager = PersistenceUtils.getEntityManager();
        TypedQuery<UserEntity> query = entityManager.createQuery("SELECT u FROM UserEntity u WHERE u.userId=?1", UserEntity.class);
        UserEntity singleResult = query.setParameter(1, userId).getSingleResult();
        return Optional.of(singleResult);
    }


}
