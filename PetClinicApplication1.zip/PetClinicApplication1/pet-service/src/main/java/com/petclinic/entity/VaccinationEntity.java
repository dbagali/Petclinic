package com.petclinic.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "VACCINATION")
public class VaccinationEntity {

    @Id
    @Column(name = "VACC_ID")
    private Long vaccinationId;

    @Column(name = "VACC_NAME")
    private String vaccinationName;

    @Column(name = "VACC_DATE")
    private LocalDateTime vaccinationDate;

    @ManyToOne
    @JoinColumn(name = "PET_ID", nullable = false)
    private PetEntity pet;

    public Long getVaccinationId() {
        return vaccinationId;
    }

    public void setVaccinationId(Long vaccinationId) {
        this.vaccinationId = vaccinationId;
    }

    public String getVaccinationName() {
        return vaccinationName;
    }

    public void setVaccinationName(String vaccinationName) {
        this.vaccinationName = vaccinationName;
    }

    public LocalDateTime getVaccinationDate() {
        return vaccinationDate;
    }

    public void setVaccinationDate(LocalDateTime vaccinationDate) {
        this.vaccinationDate = vaccinationDate;
    }
    public PetEntity getPet() {
        return pet;
    }

    public void setPet(PetEntity pet) {
        this.pet = pet;
    }
}
