package com.petclinic.ejb;

import com.petclinic.dto.User;
import com.petclinic.repo.UserRepository;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import java.util.Arrays;

@Stateless(name = "user")
public class UserRemoteImpl implements UserRemote {

    UserRepository userRepository;

    @PostConstruct
    public void init() {
        userRepository = new UserRepository();
    }

    public boolean login(User user) {
        return userRepository.findByUserIdAndPassword(user.getUserId(),
                Arrays.toString(user.getPassword())).isPresent();
    }

}
